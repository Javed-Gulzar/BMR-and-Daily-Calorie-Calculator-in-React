import "./App.css";
import BMR from "./components/bmr";

function App() {
  return (
    <div className="App">
      <BMR />
    </div>
  );
}

export default App;
